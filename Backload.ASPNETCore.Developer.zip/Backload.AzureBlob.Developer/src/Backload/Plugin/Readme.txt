Make sure the plugin supports your framework.

Right-click -> Properties -> Details